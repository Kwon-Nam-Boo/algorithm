package algo_basic.day1;

public class SWEA_9280_D3_진용이네_주차타워 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
